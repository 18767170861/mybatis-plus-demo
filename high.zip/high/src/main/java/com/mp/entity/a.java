package com.mp.entity;

public interface a {
	public default void a(){
		System.out.println("这是A");
	}

}
