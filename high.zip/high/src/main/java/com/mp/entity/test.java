
package com.mp.entity;

public class test implements a,b{

	@Override
	public void a() {
		// TODO Auto-generated method stub
		b.super.a();
	}

}
