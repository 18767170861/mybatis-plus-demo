package com.mp.entity;

public interface b {
	public default void a(){
		System.out.println("这是B");
	}
}
