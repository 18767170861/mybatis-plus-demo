package com.mp;

import java.util.Arrays;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import com.mp.dao.UserMapper;
import com.mp.entity.User;

@RunWith(SpringRunner.class)
@SpringBootTest
public class InjectorTest {
	@Autowired
	private UserMapper userMapper;
	
	//自定义sql注入器 
	@Test
	public void deleteAll(){
		int rows = userMapper.deleteAll();
		System.out.println("删除条数:"+ rows);
	}
	
	@Test
	//选装件批量插入
	public void insertBatch() {
		User user1 = new User();
		user1.setName("小明");
		user1.setAge(28);
		user1.setManagerId(1087982257332887553L);
		
		User user2 = new User();
		user2.setName("小红");
		user2.setAge(28);
		user1.setManagerId(1087982257332887553L);
		
		User user3 = new User();
		user3.setName("小花");
		user3.setAge(28);
		user3.setManagerId(1087982257332887553L);
		int insertBatchSomeColumn = userMapper.insertBatchSomeColumn(Arrays.asList(user1,user2,user3));
		System.out.println("影响行数:"+ insertBatchSomeColumn);
	}
	
	//选装件逻辑删除
	@Test
	public void deleteByIdWithFill(){
		User user = new User();
		user.setId(1216726732900442114L);
		user.setAge(88);
		int rows = userMapper.deleteByIdWithFill(user);
		System.out.println("删除条数:"+ rows);
	}
	
	//选装件：根据id更新固定的某些字段
	@Test
	public void alwaysUpdateSomeColumnById(){
		User user = new User();
		user.setName("111");
		user.setId(1216726732900442113L);
		user.setAge(88);
		int rows = userMapper.alwaysUpdateSomeColumnById(user);
		System.out.println("更新条数:"+ rows);
		
		MyLambadaInterface a = (s)->System.out.println(s);
	}
}
