package com.mp;


import java.time.LocalDateTime;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import com.mp.dao.UserMapper;
import com.mp.entity.User;

@RunWith(SpringRunner.class)
@SpringBootTest
public class FillTest {
	
	@Autowired
	private UserMapper userMapper;
	/*
	 * Preparing: UPDATE user SET deleted=1 WHERE id=? AND deleted=0 
	 */
	@Test
	public void insert() {
		User user = new User();
		user.setName("张超");
		user.setAge(30);
		user.setEmail("12234565435624323934@qq.com");
		int insert = userMapper.insert(user);
		System.out.println("影响行数：" + insert);
	}
	
	/*
	 *  Preparing: SELECT id,name,age,email,manager_id,create_time,update_time,version,deleted FROM user WHERE deleted=0
	 *  当user类中deleted字段注解@TableField(select = false)即不查出此字段
	 *  Preparing: SELECT id,name,age,email,manager_id,create_time,update_time,version FROM user WHERE deleted=
	 */
	@Test
	public void updateId() {
		User user = new User();
		user.setAge(30);
		user.setId(1216726732900442114L);
		user.setUpdateTime(LocalDateTime.now());
		int rows = userMapper.updateById(user);
		System.out.println("影响行数：" + rows);
	}
}
