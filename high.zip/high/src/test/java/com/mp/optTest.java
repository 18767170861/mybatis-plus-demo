package com.mp;


import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.mp.dao.UserMapper;
import com.mp.entity.User;

@RunWith(SpringRunner.class)
@SpringBootTest
public class optTest {
	
	@Autowired
	private UserMapper userMapper;
	
	@Test
	public void update() {
		/*
		 * Preparing: UPDATE user SET email=?, update_time=?, version=? WHERE deleted=0 AND name = ? 
		 * AND version = ? 
		 * Parameters: 123456789@QQ.COM(String), 2020-01-12 16:02:46.678(Timestamp), 3(Integer), 
		 * 王明超(String), 2(Integer)
		 */
		//数据库中原本的版本号
		int version = 2;
		User user = new User();
		user.setEmail("123456789@QQ.COM");
		user.setVersion(version);
		QueryWrapper<User> query = Wrappers.query();		
		query.eq("name","王明超");
		int update = userMapper.update(user, query);
		System.out.println("影响行数：" + update);
		/*
		 * 同一个QueryWrapper不能服用不然导致查询混乱无法更新
		 * Preparing: UPDATE user SET email=?, update_time=?, version=? WHERE deleted=0 AND name = ? 
		 * AND version = ? AND age = ? AND version = ? 
		 * Parameters: 123456789@QQ.COM(String), 2020-01-12 16:02:46.707(Timestamp), 4(Integer), 
		 * 王明超(String), 2(Integer), 31(String), 3(Integer)
		 */
		int version2 = 3;
		User user2 = new User();
		user2.setEmail("123456789@QQ.COM");
		user2.setVersion(version2);
		query.eq("age","31");
		int update2 = userMapper.update(user2, query);
		System.out.println("影响行数：" + update2);
		
		
	}
	
}
