package com.mp;

import java.util.List;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import com.baomidou.mybatisplus.autoconfigure.MybatisPlusAutoConfiguration;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.mp.configuration.MybatisPlusConfig;
import com.mp.dao.UserMapper;
import com.mp.entity.User;

@RunWith(SpringRunner.class)
@SpringBootTest
public class MyTest {
	
	@Autowired
	private UserMapper userMapper;
	/*
	 * Preparing: UPDATE user SET deleted=1 WHERE id=? AND deleted=0 
	 */
	@Test
	public void deleteById() {
		int rows = userMapper.deleteById(1094592041087729666L);
		System.out.println("影响行数：" + rows);
	}
	/*
	 *  Preparing: SELECT id,name,age,email,manager_id,create_time,update_time,version,deleted FROM user WHERE deleted=0
	 *  当user类中deleted字段注解@TableField(select = false)即不查出此字段
	 *  Preparing: SELECT id,name,age,email,manager_id,create_time,update_time,version FROM user WHERE deleted=0
	 */
	@Test
	public void select() {
		MybatisPlusConfig.myTableName.set("user_2020");
		List<User> selectList = userMapper.selectList(null);
		selectList.forEach(System.out::println);
	}
	/*
	 * Preparing: UPDATE user SET age=? WHERE id=? AND deleted=0 
	 * Parameters: 60(Integer), 1088250446457389058(Long)
	 */
	@Test
	public void updateId() {
		User user = new User();
		user.setAge(60);
		user.setId(1088250446457389058L);
		int rows = userMapper.updateById(user);
		System.out.println("影响行数：" + rows);
	}
	/*
	 * 自定义查询不会加上逻辑删除标识 需自行在sql语句中或者Wrappers条件中过滤 .eq(User::getDeleted, 0)
	 * Preparing: select * from user WHERE age > ? 
	 */
	@Test
	public void mySelect() {
		List<User> mySelectList = userMapper.mySelectList(Wrappers.<User>lambdaQuery().gt(User::getAge, 25));
		mySelectList.forEach(System.out::println);
		List<User> mySelectList1 = userMapper.mySelectList(Wrappers.<User>lambdaQuery().gt(User::getAge, 25)
				.eq(User::getDeleted, 0));
		mySelectList1.forEach(System.out::println);
		
	}
	//特定SQL过滤
	@Test
	public void selectById() {
		User user = userMapper.selectById(1216304671153491970L);
		System.out.println(user);
	}
	
	
}
