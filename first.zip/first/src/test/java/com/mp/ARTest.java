package com.mp;

import java.time.LocalDateTime;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import com.mp.entity.User;
@RunWith(SpringRunner.class)
@SpringBootTest
public class ARTest {
	//通过AR模式插入数据
	@Test
	public void insert(){
		User user = new User();
		user.setName("小白");
		user.setAge(27);
		user.setEmail("bai@qq.com");
		user.setManagerId(1088248166370832385l);
		user.setCreateTime(LocalDateTime.now());
		boolean insert = user.insert();
		System.out.println("插入结果："+insert);
 	}
	
	@Test
	public void selectById(){
		User user = new User();
		User selectUser = user.selectById(1209126219609477121L);
		System.out.println("查询结果："+selectUser);
		System.out.println(user==selectUser);
 	}
	
	@Test
	public void selectById2(){
		User user = new User();
		user.setId(1209126219609477121L);
		User selectUser = user.selectById();
		System.out.println("查询结果："+selectUser);
		System.out.println(user==selectUser);
 	}
	
	@Test
	public void updateById(){
		User user = new User();
		user.setId(1209126219609477121L);
		user.setName("小白白");
		boolean updateUser = user.updateById();
		System.out.println("更新结果："+updateUser);
 	}
	//删除的条数>=0 || 不为空 返回结果为true
	@Test
	public void deleteyId(){
		User user = new User();
		user.setId(1209126219609477121L);
		user.setName("小白白");
		boolean deleteUser = user.deleteById();
		System.out.println("删除结果："+deleteUser);
 	}
	
	@Test
	public void insertOrUpdate(){
		User user = new User();
		//如果设置id先根据id查询 查到更新数据 否则插入数据
		user.setId(1209128654407159810L);
		user.setName("小白");
		user.setAge(30);
		user.setEmail("xiaobai@qq");
		user.setCreateTime(LocalDateTime.now());
		boolean insertOrUpdate = user.insertOrUpdate();
		System.out.println("执行结果："+insertOrUpdate);
 	}
}
