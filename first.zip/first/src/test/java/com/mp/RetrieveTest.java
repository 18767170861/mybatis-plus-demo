package com.mp;

import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.core.toolkit.StringUtils;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.additional.query.impl.LambdaQueryChainWrapper;
import com.mp.dao.UserMapper;
import com.mp.entity.User;

@RunWith(SpringRunner.class)
@SpringBootTest
public class RetrieveTest {
	
	@Autowired
	private UserMapper userMapper;
	
	@Test
	public void selectById(){
		User user=userMapper.selectById(1094592041087729666L);
		System.out.println(user);
	}
	
	@Test
	public void selectIds(){
		List<Long> idList=Arrays.asList(1207630786596847618L,1207633748501102594L);
		List<User> userList=userMapper.selectBatchIds(idList);
		userList.forEach(System.out::println);
	}
	
	@Test
	public void selectByMap(){
		Map<String,Object> columnMap=new HashMap<>();
		columnMap.put("name", "小红");
		columnMap.put("age", 26);
		List<User> userList=userMapper.selectByMap(columnMap);
		userList.forEach(System.out::println);
	}
	/*
	 * 名字中包含红并且年龄小于28
	 * name like %红% and age<28
	 */
	@Test
	public void selectByWrapper(){
		QueryWrapper<User> queryWrapper = new QueryWrapper<User>();
		QueryWrapper<User> query = Wrappers.<User>query();
		queryWrapper.like("name", "红").lt("age", 28);
		List<User> selectList = userMapper.selectList(queryWrapper);
		selectList.forEach(System.out::println);
	}
	
	/*
	 * 名字中包含红年并且龄大于等于20且小于等于40并且email不为空
     * name like '%雨%' and age between 20 and 40 and name is not null
	 */
	@Test
	public void selectByWrapper2(){
		QueryWrapper<User> queryWrapper = new QueryWrapper<User>();
		//QueryWrapper<User> query = Wrappers.<User>query();
		queryWrapper.like("name", "红").between("age", 20, 40).isNotNull("name");
		List<User> selectList = userMapper.selectList(queryWrapper);
		selectList.forEach(System.out::println);
	}
	
	/*
	 * 名字为王姓或者年龄大于等于25，按照年龄降序排列，年龄相同按照id升序排列
     * name like '小%' or age>=25 order by age desc,id asc
	 */
	@Test
	public void selectByWrapper3(){
		QueryWrapper<User> queryWrapper = new QueryWrapper<User>();
		//QueryWrapper<User> query = Wrappers.<User>query();
		queryWrapper.likeRight("name", "小").or().ge("age", 25).orderByDesc("age");
		List<User> selectList = userMapper.selectList(queryWrapper);
		selectList.forEach(System.out::println);
	}
	/*
	 * 创建日期为2019年2月14日并且直属上级为名字为王姓
     * date_format(create_time,'%Y-%m-%d')='2019-02-14' and manager_id in (select id from user where name like '小%')
	 */
	@Test
	public void selectByWrapper4(){
		QueryWrapper<User> queryWrapper = new QueryWrapper<User>();
		//QueryWrapper<User> query = Wrappers.<User>query();
		queryWrapper.apply("date_format(create_time,'%Y-%m-%d') ={0}","2019-12-19").inSql("manager_id","select id from user where name like '小%'");
		List<User> selectList = userMapper.selectList(queryWrapper);
		selectList.forEach(System.out::println);
	}
	
	/*
	 * 名字为王姓或者（年龄小于40并且大于20或邮箱不为空）
	 * name like '王%' or (age<40 and age>20 or email is not null)
	 */
	@Test
	public void selectByWrapper5(){
		QueryWrapper<User> queryWrapper = new QueryWrapper<User>();
		//QueryWrapper<User> query = Wrappers.<User>query();.or().isNotNull("email")
		queryWrapper.likeRight("name", "小")
			.or(wq->wq.lt("age", 40).gt("age", 20).isNotNull("email"));
		List<User> selectList = userMapper.selectList(queryWrapper); 
		selectList.forEach(System.out::println);
	}
	
	/*
	 * 名字为王姓或者（年龄小于40并且年龄大于20并且邮箱不为空）
     * name like '王%' or (age<40 and age>20 and email is not null)
	 */
	@Test
	public void selectByWrapper6(){
		QueryWrapper<User> queryWrapper = new QueryWrapper<User>();
		//QueryWrapper<User> query = Wrappers.<User>query();.or().isNotNull("email")
		queryWrapper.likeRight("name", "小")
			.or(wq->wq.lt("age", 40).gt("age", 20).isNotNull("email"));
		List<User> selectList = userMapper.selectList(queryWrapper); 
		selectList.forEach(System.out::println);
	}
	
	/*
	 * （年龄小于40或邮箱不为空）并且名字为王姓
     *   (age<40 or email is not null) and name like '王%'
	 */
	@Test
	public void selectByWrapper7(){
		QueryWrapper<User> queryWrapper = new QueryWrapper<User>();
		//QueryWrapper<User> query = Wrappers.<User>query();.or().isNotNull("email")
		queryWrapper.nested(wr->wr.lt("age", 40).or().isNotNull("email")).likeRight("name", "王");
		List<User> selectList = userMapper.selectList(queryWrapper); 
		selectList.forEach(System.out::println);
	}
	

	/*
	 * 年龄为30、31、34、35
	 *	age in (30、31、34、35)  
	 */
	@Test
	public void selectByWrapper8(){
		QueryWrapper<User> queryWrapper = new QueryWrapper<User>();
		//QueryWrapper<User> query = Wrappers.<User>query();.or().isNotNull("email")
		queryWrapper.in("age", Arrays.asList(40,25,28));
		List<User> selectList = userMapper.selectList(queryWrapper); 
		selectList.forEach(System.out::println);
	}
	
	/*
	 * 只返回满足条件的其中一条语句即可
	 *	limit 1
	 */
	@Test
	public void selectByWrapper9(){
		QueryWrapper<User> queryWrapper = new QueryWrapper<User>();
		//QueryWrapper<User> query = Wrappers.<User>query();.or().isNotNull("email")
		queryWrapper.last("limit 1"); //queryWrapper.apply("1=1 limit {0}", 1);
		List<User> selectList = userMapper.selectList(queryWrapper); 
		selectList.forEach(System.out::println);
	}
	
	/*
	 * 名字中包含雨并且年龄小于40(需求1加强版)
	 *	第一种情况：select id,name
	 *        from user
	 *        where name like '%雨%' and age<40
	 *  第二种情况：select id,name,age,email
	 *        from user
	 *        where name like '%雨%' and age<40
	 */
	@Test
	public void selectByWrapper10(){
		QueryWrapper<User> queryWrapper = new QueryWrapper<User>();
		//QueryWrapper<User> query = Wrappers.<User>query();.or().isNotNull("email")
		//select可以放在前面也可以放在后面
		queryWrapper.select("id,name").like("name", "雨").lt("age", 40);
		List<User> selectList = userMapper.selectList(queryWrapper); 
		selectList.forEach(System.out::println);
	}
	@Test
	public void selectByWrapper11(){
		QueryWrapper<User> queryWrapper = new QueryWrapper<User>();
		//QueryWrapper<User> query = Wrappers.<User>query();.or().isNotNull("email")
		//select可以放在前面也可以放在后面
		queryWrapper.like("name", "雨").lt("age", 40)
			.select(User.class,info->!info.getColumn().equals("create_time")&&
					!info.getColumn().equals("manager_id"));
		List<User> selectList = userMapper.selectList(queryWrapper); 
		selectList.forEach(System.out::println);
	}
	
	@Test
	public void conditionTest() {
		String name="王";
		String email="";
		condition(name,email);
	}
	
	private void condition(String name,String email) {
		QueryWrapper<User> queryWrapper = new QueryWrapper<User>();
//		if(StringUtils.isNotEmpty(name)) {
//			queryWrapper.like("name", name);
//		}
//		if(StringUtils.isNotEmpty(email)) {
//			queryWrapper.like("email", email);
//		}
		//第一个参数为boolear值当为true该条件加入到where语句
		queryWrapper.like(StringUtils.isNotEmpty(name),"name", name);
		queryWrapper.like(StringUtils.isNotEmpty(email),"email", email);
		List<User> selectList = userMapper.selectList(queryWrapper); 
		selectList.forEach(System.out::println);
	}
	
	@Test
	public void selectByWrapperEntity(){
		User whereUser = new User();
		whereUser.setName("小红");
		whereUser.setAge(26);
		QueryWrapper<User> queryWrapper = new QueryWrapper<User>(whereUser);
		List<User> selectList = userMapper.selectList(queryWrapper); 
		selectList.forEach(System.out::println);
	}
	
	@Test
	public void selectByWrapperAlleq(){
		QueryWrapper<User> queryWrapper = new QueryWrapper<User>();
		Map<String,Object> params=new HashMap<String, Object>();
		params.put("name", "王天风");
		params.put("age", null);
		//queryWrapper.allEq(params);
		//第二个参数为boolean值 默认为true 为false表示此值为null不加入where语句
		//queryWrapper.allEq(params,false);
		//k代表map的key值 v代表key对应的value值 
		queryWrapper.allEq((k,v)->!k.equals("name"), params);
		List<User> selectList = userMapper.selectList(queryWrapper); 
		selectList.forEach(System.out::println);
	}
	//SELECT id,name FROM user WHERE name=? AND age=? 
	@Test
	public void selectByWrapperMaps(){
		User whereUser = new User();
		whereUser.setName("小红");
		whereUser.setAge(26);
		QueryWrapper<User> queryWrapper = new QueryWrapper<User>(whereUser);
		queryWrapper.select("id","name");
		List<Map<String,Object>> selectList = userMapper.selectMaps(queryWrapper);
		selectList.forEach(System.out::println);
	}
	/*
	 * 按照直属上级分组，查询每组的平均年龄、最大年龄、最小年龄
	 * 并且只取年龄总和小于500的组
	 * select avg(age) avg_age,min(age) min_age,max(age) max_age from user 
	 * group by manager_id having sum(age) <500
	 * SELECT avg(age) avg_age,min(age) min_age,max(age) max_age FROM user GROUP BY manager_id HAVING sum(age) < ?
	 */
	@Test
	public void selectByWrapperMaps2(){
		QueryWrapper<User> queryWrapper = new QueryWrapper<User>();
		queryWrapper.select("avg(age) avg_age","min(age) min_age","max(age) max_age")
			.groupBy("manager_id").having("sum(age) < {0}", 500);
		List<Map<String,Object>> selectList = userMapper.selectMaps(queryWrapper);
		selectList.forEach(System.out::println);
	}
	//只返回结果的第一列
	//(SELECT id,name,age,email,manager_id,create_time FROM user WHERE name LIKE ? OR ( age < ? AND age > ? AND email IS NOT NULL ) )
	@Test
	public void selectByWrapperObjs(){
		QueryWrapper<User> queryWrapper = new QueryWrapper<User>();
		//QueryWrapper<User> query = Wrappers.<User>query();.or().isNotNull("email")
		queryWrapper.likeRight("name", "小")
			.or(wq->wq.lt("age", 40).gt("age", 20).isNotNull("email"));
		
		List<Object> selectList = userMapper.selectObjs(queryWrapper);
		selectList.forEach(System.out::println);
	}
	//只获取一条查询结果 如果返回多条则报错
	//（SELECT id,name,age,email,manager_id,create_time FROM user WHERE name LIKE ?）
	@Test
	public void selectByWrapperCount(){
		QueryWrapper<User> queryWrapper = new QueryWrapper<User>();
		//QueryWrapper<User> query = Wrappers.<User>query();.or().isNotNull("email")
		queryWrapper.like("name", "小红");
		User user = userMapper.selectOne(queryWrapper);
		System.out.println(user);
	}
	
	//查询总记录数（SELECT COUNT( 1 ) FROM user）
	@Test
	public void selectByWrapperOne(){
		QueryWrapper<User> queryWrapper = new QueryWrapper<User>();
		Integer selectCount = userMapper.selectCount(queryWrapper);
		System.out.println("总记录数："+ selectCount);
	}
	//Lambda表达式条件构造器
	@Test
	public void selectByLambda(){
		//LambdaQueryWrapper<User> lambda = new QueryWrapper<User>().lambda();
		//LambdaQueryWrapper<User> lambdaQueryWrapper = new LambdaQueryWrapper<User>();
		LambdaQueryWrapper<User> lambdaQuery = Wrappers.lambdaQuery();
		lambdaQuery.like(User::getName, "雨").lt(User::getAge, 40);
		//where name like %雨% 
		List<User> userList = userMapper.selectList(lambdaQuery);
		userList.forEach(user -> System.out.println(user));
	}
	
	@Test
	public void selectByLambda2(){
		//LambdaQueryWrapper<User> lambda = new QueryWrapper<User>().lambda();
		//LambdaQueryWrapper<User> lambdaQueryWrapper = new LambdaQueryWrapper<User>();
		LambdaQueryWrapper<User> lambdaQuery = Wrappers.lambdaQuery();
		lambdaQuery.likeRight(User::getName, "小")
		.and(lqw->lqw.lt(User::getAge, 40).or().isNotNull(User::getEmail));
		//where name like %雨% 
		List<User> userList = userMapper.selectList(lambdaQuery);
		userList.forEach(user -> System.out.println(user));
	}
	//链式Lambda条件构造器
	@Test
	public void selectByLambda3(){
		List<User> list = new LambdaQueryChainWrapper<>(userMapper).like(User::getName, "小")
			.ge(User::getAge, 20).list();
		list.forEach(System.out::println);
	}
	//自定义sql
	@Test
	public void selectMy(){
		LambdaQueryWrapper<User> lambdaQuery = Wrappers.lambdaQuery();
		lambdaQuery.like(User::getName, "雨").lt(User::getAge, 40);
		List<User> list = userMapper.selectAll(lambdaQuery);
		list.forEach(System.out::println);
	}
	//分页查询返回为对象类型
	@Test
	public void selectPage(){
		QueryWrapper<User> queryWrapper = new QueryWrapper<User>();
		queryWrapper.ge("age", 20);
		Page<User> page = new Page<User>(1, 3);
		IPage<User> iPage = userMapper.selectPage(page, queryWrapper);
		System.out.println("总页数："+ iPage.getPages());
		System.out.println("总记录数："+ iPage.getTotal());
		List<User> userList = iPage.getRecords();
		userList.forEach(System.out::println);
	}
	//分页查询返回为Map类型
	@Test
	public void selectMapsPage(){
		QueryWrapper<User> queryWrapper = new QueryWrapper<User>();
		queryWrapper.ge("age", 20);
		Page<User> page = new Page<User>(1, 3);
		IPage<Map<String,Object>> iPage = userMapper.selectMapsPage(page, queryWrapper);
		System.out.println("总页数："+ iPage.getPages());
		System.out.println("总记录数："+ iPage.getTotal());
		List<Map<String,Object>> userList = iPage.getRecords();
		userList.forEach(System.out::println);
	}
	//自定义分页查询返回为Map类型
	@Test
	public void selectUserPage(){
		QueryWrapper<User> queryWrapper = new QueryWrapper<User>();
		queryWrapper.ge("age", 20);
		Page<User> page = new Page<User>(1, 3);
		IPage<User> iPage = userMapper.selectUserPage(page, queryWrapper);
		System.out.println("总页数："+ iPage.getPages());
		System.out.println("总记录数："+ iPage.getTotal());
		List<User> userList = iPage.getRecords();
		userList.forEach(System.out::println);
	}
}
