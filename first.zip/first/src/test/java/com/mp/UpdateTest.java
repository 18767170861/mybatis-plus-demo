package com.mp;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import com.baomidou.mybatisplus.core.conditions.update.LambdaUpdateWrapper;
import com.baomidou.mybatisplus.core.conditions.update.UpdateWrapper;
import com.baomidou.mybatisplus.extension.service.additional.update.impl.LambdaUpdateChainWrapper;
import com.mp.dao.UserMapper;
import com.mp.entity.User;

@RunWith(SpringRunner.class)
@SpringBootTest
public class UpdateTest {
	@Autowired
	private UserMapper userMapper;
	//根据id更新
	@Test
	public void updateById(){
		User user =new User();
		//user.setId(1207595197368279041L);
		user.setEmail("hhhhhhh@qq.com");
		int updateById = userMapper.updateById(user);
		System.out.println("影响记录数:"+updateById);
	}
	//根据UpdateWrapper条件更新
	@Test
	public void updateByWrapper(){
		UpdateWrapper<User> updateWrapper = new UpdateWrapper<User>();
		updateWrapper.eq("name", "小花").eq("age", 27);
		User user = new User();
		user.setEmail("huahuahuahua@qq.com");
		user.setAge(29);
		int update = userMapper.update(user, updateWrapper);
		System.out.println("影响记录数:"+update);
	}
	//根据UpdateWrapper实体条件更新
	@Test
	public void updateByWrapper1(){
		User whereUser = new User();
		whereUser.setName("小明");
		UpdateWrapper<User> updateWrapper = new UpdateWrapper<User>(whereUser);
		updateWrapper.eq("name", "小明").eq("age", 30);
		User user = new User();
		user.setEmail("XXXXXXXXX@qq.com");
		user.setAge(31);
		int update = userMapper.update(user, updateWrapper);
		System.out.println("影响记录数:"+update);
	}
	//根据UpdateWrapper set方法更新
	@Test
	public void updateByWrapper2(){
		UpdateWrapper<User> updateWrapper = new UpdateWrapper<User>();
		updateWrapper.eq("name", "小红").eq("age", 26).set("age", 30);
		int update = userMapper.update(null, updateWrapper);
		System.out.println("影响记录数:"+update);
	}
	
	//根据Lambda更新
	@Test
	public void updateByWrapperLambda(){
		LambdaUpdateWrapper<User> updateWrapper = new LambdaUpdateWrapper<User>();
		updateWrapper.eq(User::getName, "王天风").eq(User::getAge, 25).set(User::getAge, 33);
		int update = userMapper.update(null, updateWrapper);
		System.out.println("影响记录数:"+update);
	}
	//链式Lambda更新
	@Test
	public void updateByWrapperLambdaChain(){
		boolean update = new LambdaUpdateChainWrapper<User>(userMapper)
			.eq(User::getName, "王天风").eq(User::getAge, 33).set(User::getAge, 33).update();
		System.out.println("更新结果:"+update);
	}
}
