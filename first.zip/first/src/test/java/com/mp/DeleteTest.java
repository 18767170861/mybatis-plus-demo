package com.mp;

import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.mp.dao.UserMapper;
import com.mp.entity.User;

@RunWith(SpringRunner.class)
@SpringBootTest
public class DeleteTest {
	@Autowired
	private UserMapper userMapper;
	
	//根据id删除
	@Test
	public void deleteById(){
		int deleteById = userMapper.deleteById(1207633748501102594L);
		System.out.println("删除条数:"+deleteById);
	}
	
	//根据Map删除
	@Test
	public void deleteByMap(){
		Map<String, Object> columnMap=new HashMap<String, Object>();
		columnMap.put("name", "小蓝");
		columnMap.put("age", 27);
		int deleteById = userMapper.deleteByMap(columnMap);
		System.out.println("删除条数:"+deleteById);
	}
	
	//根据id集合删除
	@Test
	public void deleteByBatchIds(){
		int deleteBatchIds = userMapper.deleteBatchIds(Arrays.asList(1094590409767661571L,11111L));
		System.out.println("删除条数:"+deleteBatchIds);
	}
	
	//根据LabdaQueryWrapper集合删除
	@Test
	public void deleteByWrapper(){
		LambdaQueryWrapper<User> lambdaQuery = Wrappers.<User>lambdaQuery();
		lambdaQuery.eq(User::getName, "小红").or().ge(User::getAge, 50);
		int delete = userMapper.delete(lambdaQuery);
		System.out.println("删除条数:"+delete);
	}
}
