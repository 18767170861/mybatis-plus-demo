package com.mp;

import java.util.Arrays;
import java.util.List;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.baomidou.mybatisplus.extension.service.additional.update.impl.LambdaUpdateChainWrapper;
import com.mp.entity.User;
import com.mp.service.UserService;

@RunWith(SpringRunner.class)
@SpringBootTest
public class ServiceTest {
	@Autowired
	private UserService UserService;
	
	@Test
	public void getOne() {
		User one =  UserService.getOne(Wrappers.<User>lambdaQuery().gt(User::getAge, 25),false);
		System.out.println(one);
	}
	
	@Test
	public void batch() {
		User user1 = new User();
		user1.setName("向阳1");
		user1.setAge(26);
		
		User user2 = new User();
		user2.setName("向阳2");
		user2.setAge(26);
		List<User> userList = Arrays.asList(user1,user2);
		boolean saveBatch = UserService.saveBatch(userList);
		System.out.println(saveBatch);
	}
	//链式Lambda查询
	@Test
	public void chain() {
		List<User> list = UserService.lambdaQuery().gt(User::getAge, 25).like(User::getName, "向").list();
		list.forEach(System.out::println);
	}
	//链式Lambda更新//也可以通过remove进行删除
	@Test
	public void chain1() {
		//boolean update = UserService.lambdaUpdate().eq(User::getAge, 26).set(User::getAge, 28).update();
		boolean remove = UserService.lambdaUpdate().eq(User::getAge, 26).set(User::getAge, 28).remove();
		System.out.println(remove);
	}
}
